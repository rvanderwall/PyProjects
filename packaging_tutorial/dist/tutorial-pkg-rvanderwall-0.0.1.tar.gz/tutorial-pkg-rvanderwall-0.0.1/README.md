# Set up
```
pip install --upgrade build
```

#  Create src directory and code under it
#  Create pyproject.toml
#  Create setup.cfg

# build package
```
python -m build
```
