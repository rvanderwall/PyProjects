# https://packaging.python.org/tutorials/packaging-projects/
# https://docs.python.org/3/tutorial/modules.html#packages


def add_one(number):
    return number + 1

